plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.gesturex.ai"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.gesturex.ai"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            // Firmado con la clave de debug para poder instalar el APK de release directamente.
            signingConfig = signingConfigs.getByName("debug")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }
    androidResources { noCompress += "task" }
    packaging { resources.excludes += "/META-INF/{AL2.0,LGPL2.1}" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.3")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-core")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    val camerax = "1.3.4"
    implementation("androidx.camera:camera-core:$camerax")
    implementation("androidx.camera:camera-camera2:$camerax")
    implementation("androidx.camera:camera-lifecycle:$camerax")
    implementation("androidx.camera:camera-view:$camerax")

    implementation("com.google.mediapipe:tasks-vision:0.10.14")
}

// Descarga el modelo oficial de MediaPipe (una sola vez) a assets/ antes de compilar.
val modelFile = file("src/main/assets/gesture_recognizer.task")
val downloadModel by tasks.registering {
    onlyIf { !modelFile.exists() }
    doLast {
        modelFile.parentFile.mkdirs()
        try {
            java.net.URL("https://storage.googleapis.com/mediapipe-models/gesture_recognizer/gesture_recognizer/float16/1/gesture_recognizer.task")
                .openStream().use { input -> modelFile.outputStream().use { out -> input.copyTo(out) } }
        } catch (e: Exception) {
            modelFile.delete()
            throw GradleException("No se pudo descargar el modelo. Descarga gesture_recognizer.task manualmente en app/src/main/assets/ (ver README).", e)
        }
    }
}
tasks.named("preBuild") { dependsOn(downloadModel) }
