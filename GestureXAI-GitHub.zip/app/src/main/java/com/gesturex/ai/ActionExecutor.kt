package com.gesturex.ai

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.provider.Settings
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat

class ActionExecutor(private val ctx: Context) {
    /** La pantalla «Activar» lo rellena cuando hay una sesión de cámara propia con ImageCapture. */
    var photoCapturer: (suspend () -> ActionResult)? = null
    private var torchOn = false

    suspend fun run(a: ActionConfig): ActionResult = try {
        when (a.type) {
            ActionType.OPEN_BROWSER -> openUrl(a.param.ifBlank { "https://www.google.com" })
            ActionType.OPEN_URL ->
                if (a.param.isBlank()) ActionResult(false, "Falta el enlace.") else openUrl(a.param)
            ActionType.OPEN_YOUTUBE -> {
                val i = ctx.packageManager.getLaunchIntentForPackage("com.google.android.youtube")
                if (i != null) launch(i, "YouTube lanzado.") else openUrl("https://www.youtube.com")
            }
            ActionType.OPEN_APP -> {
                val i = if (a.param.isBlank()) null else ctx.packageManager.getLaunchIntentForPackage(a.param)
                if (i == null) ActionResult(false, "Aplicación no elegida o no instalada.")
                else launch(i, "Aplicación lanzada.")
            }
            ActionType.OPEN_CAMERA -> openCamera(a.param2)
            ActionType.PHOTO_AUTO -> {
                val cap = photoCapturer
                if (cap != null) cap() else {
                    openCamera("")
                    ActionResult(true, "NO se tomó ninguna foto: la captura automática solo funciona con la pantalla «Activar» abierta. Se abrió la cámara; pulsa el obturador.", true)
                }
            }
            ActionType.OPEN_SETTINGS -> launch(Intent(Settings.ACTION_SETTINGS), "Ajustes lanzados.")
            ActionType.FLASHLIGHT -> flashlight()
            ActionType.VOLUME_UP -> volume(AudioManager.ADJUST_RAISE, "Volumen subido.")
            ActionType.VOLUME_DOWN -> volume(AudioManager.ADJUST_LOWER, "Volumen bajado.")
            ActionType.NOTIFICATION -> notify(a.param)
            ActionType.GO_HOME -> global(AccessibilityService.GLOBAL_ACTION_HOME, "Inicio")
            ActionType.SCREENSHOT ->
                if (Build.VERSION.SDK_INT < 28) ActionResult(false, "La captura de pantalla requiere Android 9 o superior.")
                else global(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT, "Captura de pantalla")
        }
    } catch (e: Exception) {
        ActionResult(false, "Error: ${e.message}")
    }

    private fun launch(i: Intent, ok: String): ActionResult = try {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
        ActionResult(true, ok)
    } catch (e: Exception) { ActionResult(false, "No se pudo abrir: ${e.message}") }

    private fun openUrl(raw: String): ActionResult {
        val url = if (raw.contains("://")) raw else "https://$raw"
        return launch(Intent(Intent.ACTION_VIEW, Uri.parse(url)), "Enlace lanzado.")
    }

    private fun openCamera(facing: String): ActionResult {
        val i = Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
        when (facing) {
            "front" -> { i.putExtra("android.intent.extras.CAMERA_FACING", 1); i.putExtra("android.intent.extra.USE_FRONT_CAMERA", true) }
            "back" -> { i.putExtra("android.intent.extras.CAMERA_FACING", 0) }
        }
        return launch(i, "Cámara abierta (no se ha tomado ninguna foto).")
    }

    private fun flashlight(): ActionResult {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull {
            val c = cm.getCameraCharacteristics(it)
            c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
        } ?: return ActionResult(false, "Este dispositivo no tiene linterna accesible.")
        cm.setTorchMode(id, !torchOn)
        torchOn = !torchOn
        return ActionResult(true, if (torchOn) "Linterna encendida." else "Linterna apagada.")
    }

    private fun volume(dir: Int, msg: String): ActionResult {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI)
        return ActionResult(true, msg)
    }

    private fun notify(text: String): ActionResult {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return ActionResult(false, "Falta el permiso de notificaciones: concédelo en Ajustes > Apps > GestureX AI.", true)
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("gx", "GestureX AI", NotificationManager.IMPORTANCE_DEFAULT))
        val n = NotificationCompat.Builder(ctx, "gx")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("GestureX AI")
            .setContentText(text.ifBlank { "Gesto reconocido" })
            .setAutoCancel(true).build()
        nm.notify(System.currentTimeMillis().toInt(), n)
        return ActionResult(true, "Notificación mostrada.")
    }

    private fun global(action: Int, label: String): ActionResult {
        val svc = GestureAccessibilityService.instance
        if (svc == null) {
            launch(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS), "")
            return ActionResult(false, "Activa el servicio de accesibilidad «GestureX AI» en los ajustes que se han abierto y vuelve a intentarlo.", true)
        }
        return if (svc.performGlobalAction(action)) ActionResult(true, "$label: Android aceptó la orden.")
        else ActionResult(false, "$label: Android rechazó la orden.")
    }
}
