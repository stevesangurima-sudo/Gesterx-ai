package com.gesturex.ai

import kotlinx.coroutines.delay

/**
 * Decide cuándo se dispara una regla: tiempo mínimo de reconocimiento, tiempo de espera entre
 * ejecuciones y obligación de volver a una posición neutral (gesto ausente ≥400 ms) antes de repetir.
 */
class RuleDispatcher(private val onFire: (Rule) -> Unit) {
    private class S { var holdStart = 0L; var absentStart = 0L; var armed = true; var lastFire = 0L }
    private val states = HashMap<String, S>()

    fun update(rules: List<Rule>, present: Set<GestureId>, now: Long) {
        for (r in rules) {
            if (!r.enabled) continue
            val s = states.getOrPut(r.id) { S() }
            if (r.gesture in present) {
                s.absentStart = 0
                if (s.holdStart == 0L) s.holdStart = now
                val held = r.gesture.movement || now - s.holdStart >= r.minHoldMs
                val cooled = s.lastFire == 0L || now - s.lastFire >= r.cooldownMs
                if (s.armed && held && cooled) { s.armed = false; s.lastFire = now; onFire(r) }
            } else {
                s.holdStart = 0
                if (s.absentStart == 0L) s.absentStart = now
                if (now - s.absentStart >= 400) s.armed = true
            }
        }
    }
}

/** Ejecuta los pasos en orden; se detiene si un paso falla o necesita intervención del usuario. */
suspend fun runSequence(ex: ActionExecutor, steps: List<ActionConfig>): ActionResult {
    var last = ActionResult(false, "Sin pasos")
    for ((i, s) in steps.withIndex()) {
        last = ex.run(s)
        val tag = if (steps.size > 1) "Paso ${i + 1}/${steps.size}: " else ""
        if (!last.ok || last.needsUser) {
            val suffix = if (steps.size > 1) " Secuencia detenida." else ""
            return ActionResult(last.ok, tag + last.message + suffix, last.needsUser)
        }
        if (i < steps.lastIndex) delay(700)
    }
    return last
}
