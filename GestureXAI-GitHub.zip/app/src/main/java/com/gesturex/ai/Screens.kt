package com.gesturex.ai

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.view.PreviewView
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import kotlinx.coroutines.launch

sealed interface Screen {
    data object Home : Screen
    data object Library : Screen
    data object Live : Screen
    data class Wizard(val ruleId: String?) : Screen
}

@Composable
fun AppRoot(store: Store, executor: ActionExecutor) {
    val ctx = LocalContext.current
    val rules = remember { mutableStateListOf<Rule>().apply { addAll(store.loadRules()) } }
    val persist = { store.saveRules(rules.toList()) }
    var screen by remember { mutableStateOf<Screen>(Screen.Home) }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    BackHandler(screen != Screen.Home) { screen = Screen.Home }

    when (val s = screen) {
        Screen.Home -> HomeScreen(rules, persist, executor,
            onCreate = { screen = Screen.Wizard(null) },
            onEdit = { screen = Screen.Wizard(it.id) },
            onLibrary = { screen = Screen.Library },
            onLive = { screen = Screen.Live })
        Screen.Library -> LibraryScreen(onBack = { screen = Screen.Home }, onLive = { screen = Screen.Live })
        Screen.Live -> LiveScreen(store, rules, executor) { screen = Screen.Home }
        is Screen.Wizard -> {
            val existing = rules.firstOrNull { it.id == s.ruleId }
            WizardScreen(existing, executor,
                onSave = { r ->
                    val i = rules.indexOfFirst { it.id == r.id }
                    if (i >= 0) rules[i] = r else rules.add(r)
                    persist(); screen = Screen.Home
                },
                onCancel = { screen = Screen.Home })
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    rules: androidx.compose.runtime.snapshots.SnapshotStateList<Rule>,
    persist: () -> Unit,
    executor: ActionExecutor,
    onCreate: () -> Unit, onEdit: (Rule) -> Unit, onLibrary: () -> Unit, onLive: () -> Unit
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    Scaffold(topBar = { TopAppBar(title = { Text("GestureX AI") }) }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp)) {
            Button(onClick = onCreate, modifier = Modifier.fillMaxWidth()) { Text("Crear mi gesto") }
            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onLibrary, modifier = Modifier.weight(1f)) { Text("Biblioteca") }
                OutlinedButton(onClick = onLive, modifier = Modifier.weight(1f)) { Text("Activar / Probar") }
            }
            if (rules.isEmpty()) Text("Aún no tienes reglas. Pulsa «Crear mi gesto».")
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(rules.toList(), key = { it.id }) { r ->
                    val i = rules.indexOfFirst { it.id == r.id }
                    var menu by remember { mutableStateOf(false) }
                    Card(Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(r.name, style = MaterialTheme.typography.titleMedium)
                                Text(r.gesture.label + " → " + r.steps.joinToString(" → ") { it.type.label },
                                    style = MaterialTheme.typography.bodySmall)
                            }
                            Switch(checked = r.enabled, onCheckedChange = { rules[i] = r.copy(enabled = it); persist() })
                            Box {
                                IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, "Más") }
                                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                                    DropdownMenuItem(text = { Text("Probar acción") }, onClick = {
                                        menu = false
                                        scope.launch {
                                            val res = runSequence(executor, r.steps)
                                            Toast.makeText(ctx, res.message, Toast.LENGTH_LONG).show()
                                        }
                                    })
                                    DropdownMenuItem(text = { Text("Editar") }, onClick = { menu = false; onEdit(r) })
                                    DropdownMenuItem(text = { Text("Duplicar") }, onClick = {
                                        menu = false
                                        rules.add(i + 1, r.copy(id = java.util.UUID.randomUUID().toString(), name = r.name + " (copia)"))
                                        persist()
                                    })
                                    DropdownMenuItem(text = { Text("Subir") }, onClick = {
                                        menu = false
                                        if (i > 0) { rules.add(i - 1, rules.removeAt(i)); persist() }
                                    })
                                    DropdownMenuItem(text = { Text("Bajar") }, onClick = {
                                        menu = false
                                        if (i < rules.lastIndex) { rules.add(i + 1, rules.removeAt(i)); persist() }
                                    })
                                    DropdownMenuItem(text = { Text("Eliminar") }, onClick = {
                                        menu = false; rules.removeAt(i); persist()
                                    })
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LibraryScreen(onBack: () -> Unit, onLive: () -> Unit) {
    Scaffold(topBar = { TopAppBar(title = { Text("Biblioteca de gestos") }, navigationIcon = { TextButton(onClick = onBack) { Text("Atrás") } }) }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Estos son los gestos que la app puede detectar. Los marcados como heurísticos o experimentales son menos fiables: compruébalos en la pantalla de prueba antes de depender de ellos.")
            GestureId.values().forEach { g ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text(g.label, style = MaterialTheme.typography.titleSmall)
                        Text(g.rel.label, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            Text("No incluidos: «Cinco dedos» es indistinguible de «Palma abierta» y «Dos dedos» de «Signo de paz» para este modelo. " +
                "Tampoco se pueden crear gestos nuevos: la app no entrena modelos y no simula aprendizaje.")
            Button(onClick = onLive, modifier = Modifier.fillMaxWidth()) { Text("Probar gestos con la cámara") }
        }
    }
}

@Composable
fun AppPickerDialog(onPick: (String) -> Unit, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val apps = remember {
        val pm = ctx.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        pm.queryIntentActivities(i, 0)
            .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
            .distinctBy { it.second }.sortedBy { it.first.lowercase() }
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Cerrar") } },
        title = { Text("Elige una aplicación") },
        text = {
            LazyColumn {
                items(apps) { (label, pkg) ->
                    Text(label, Modifier.fillMaxWidth().clickable { onPick(pkg) }.padding(12.dp))
                }
            }
        })
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WizardScreen(existing: Rule?, executor: ActionExecutor, onSave: (Rule) -> Unit, onCancel: () -> Unit) {
    var step by remember { mutableIntStateOf(0) }
    var gesture by remember { mutableStateOf(existing?.gesture) }
    val steps = remember { mutableStateListOf<ActionConfig>().apply { existing?.let { addAll(it.steps) } } }
    var hold by remember { mutableFloatStateOf((existing?.minHoldMs ?: 500).toFloat()) }
    var cooldown by remember { mutableFloatStateOf((existing?.cooldownMs ?: 3000).toFloat()) }
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var testMsg by remember { mutableStateOf("") }
    var picking by remember { mutableStateOf<Int?>(null) }
    val scope = rememberCoroutineScope()
    val titles = listOf("1. Elige un gesto", "2. Elige la acción", "3. Parámetros", "4. Probar", "5. Guardar")
    val canNext = when (step) { 0 -> gesture != null; 1 -> steps.isNotEmpty(); 4 -> name.isNotBlank(); else -> true }

    picking?.let { idx ->
        AppPickerDialog(onPick = { pkg -> steps[idx] = steps[idx].copy(param = pkg); picking = null }, onDismiss = { picking = null })
    }

    Scaffold(topBar = { TopAppBar(title = { Text(titles[step]) }) }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp)) {
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                when (step) {
                    0 -> GestureId.values().forEach { g ->
                        Row(Modifier.fillMaxWidth().clickable { gesture = g }, verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = gesture == g, onClick = { gesture = g })
                            Column { Text(g.label); Text(g.rel.label, style = MaterialTheme.typography.bodySmall) }
                        }
                    }
                    1 -> {
                        Text("Pulsa una acción para añadirla. Con varias acciones creas una secuencia.")
                        if (steps.size > 1) Text("Aviso: si un paso abre otra app, Android puede bloquear sin avisar que pasos posteriores abran más apps. Pon los pasos que abren apps al final.", style = MaterialTheme.typography.bodySmall)
                        steps.forEachIndexed { i, s ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("${i + 1}. ${s.type.label}", Modifier.weight(1f))
                                TextButton(onClick = { steps.removeAt(i) }) { Text("Quitar") }
                            }
                        }
                        HorizontalDivider()
                        ActionType.values().forEach { t ->
                            Column(Modifier.fillMaxWidth().clickable { steps.add(ActionConfig(t)) }.padding(vertical = 6.dp)) {
                                Text("＋ " + t.label, style = MaterialTheme.typography.titleSmall)
                                Text(t.note, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                    2 -> {
                        steps.forEachIndexed { i, s ->
                            Text("${i + 1}. ${s.type.label}", style = MaterialTheme.typography.titleSmall)
                            when (s.type) {
                                ActionType.OPEN_BROWSER, ActionType.OPEN_URL -> OutlinedTextField(
                                    value = s.param, onValueChange = { steps[i] = s.copy(param = it) },
                                    label = { Text("URL") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                                ActionType.NOTIFICATION -> OutlinedTextField(
                                    value = s.param, onValueChange = { steps[i] = s.copy(param = it) },
                                    label = { Text("Texto") }, modifier = Modifier.fillMaxWidth())
                                ActionType.OPEN_APP -> {
                                    Text(if (s.param.isBlank()) "Ninguna app elegida" else s.param, style = MaterialTheme.typography.bodySmall)
                                    OutlinedButton(onClick = { picking = i }) { Text("Elegir aplicación") }
                                }
                                ActionType.OPEN_CAMERA -> Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    listOf("" to "Predeterminada", "front" to "Frontal", "back" to "Trasera").forEach { (v, l) ->
                                        FilterChip(selected = s.param2 == v, onClick = { steps[i] = s.copy(param2 = v) }, label = { Text(l) })
                                    }
                                }
                                else -> Text("Sin parámetros.", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                        HorizontalDivider()
                        if (gesture?.movement == true) Text("Los movimientos se detectan al instante; el tiempo mínimo no se aplica.")
                        else {
                            Text("Tiempo mínimo de reconocimiento: ${hold.toInt()} ms")
                            Slider(value = hold, onValueChange = { hold = it }, valueRange = 200f..2000f)
                        }
                        Text("Espera antes de volver a ejecutarse: ${cooldown.toInt()} ms")
                        Slider(value = cooldown, onValueChange = { cooldown = it }, valueRange = 1000f..10000f)
                        Text("Además, la mano debe volver a una posición neutral (sin el gesto) antes de repetir.", style = MaterialTheme.typography.bodySmall)
                    }
                    3 -> {
                        Text("Prueba la acción ahora. Para probar el gesto con la cámara, guarda la regla y usa «Activar / Probar».")
                        Button(onClick = { scope.launch { testMsg = runSequence(executor, steps.toList()).message } }) { Text("Probar acción") }
                        if (testMsg.isNotBlank()) Text(testMsg)
                    }
                    else -> OutlinedTextField(value = name, onValueChange = { name = it },
                        label = { Text("Nombre (p. ej. «Mi acceso rápido»)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                }
            }
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { if (step == 0) onCancel() else step-- }, modifier = Modifier.weight(1f)) {
                    Text(if (step == 0) "Cancelar" else "Atrás")
                }
                Button(enabled = canNext, modifier = Modifier.weight(1f), onClick = {
                    if (step < 4) step++ else onSave(Rule(
                        id = existing?.id ?: java.util.UUID.randomUUID().toString(),
                        name = name.trim(), gesture = gesture!!, steps = steps.toList(),
                        enabled = existing?.enabled ?: true, minHoldMs = hold.toInt(), cooldownMs = cooldown.toInt()))
                }) { Text(if (step < 4) "Siguiente" else "Guardar") }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LiveScreen(store: Store, rules: List<Rule>, executor: ActionExecutor, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()
    var hasCam by remember { mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { hasCam = it }
    var minScore by remember { mutableFloatStateOf(store.minScore) }
    var runRules by remember { mutableStateOf(false) }
    var frame by remember { mutableStateOf<Frame?>(null) }
    var status by remember { mutableStateOf("") }
    val rulesNow by rememberUpdatedState(rules)
    val runNow by rememberUpdatedState(runRules)
    val scoreNow by rememberUpdatedState(minScore)
    val main = remember { Handler(Looper.getMainLooper()) }

    Scaffold(topBar = { TopAppBar(title = { Text("Probar y activar") }, navigationIcon = { TextButton(onClick = onBack) { Text("Atrás") } }) }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (!hasCam) {
                Text("Se necesita permiso de cámara. El vídeo se procesa solo en el teléfono y nunca se envía a Internet.")
                Button(onClick = { launcher.launch(Manifest.permission.CAMERA) }) { Text("Conceder permiso de cámara") }
            } else {
                val dispatcher = remember {
                    RuleDispatcher { rule -> scope.launch { status = "${rule.name}: " + runSequence(executor, rule.steps).message } }
                }
                val engine = remember {
                    GestureEngine(ctx, { scoreNow },
                        { f -> main.post { frame = f; if (runNow) dispatcher.update(rulesNow, f.gestures, SystemClock.uptimeMillis()) } },
                        { m -> main.post { status = m } })
                }
                val session = remember { CameraSession(ctx, owner) }
                DisposableEffect(Unit) {
                    executor.photoCapturer = { session.takePhoto() }
                    onDispose { executor.photoCapturer = null; session.stop(); engine.close() }
                }
                AndroidView(factory = { c ->
                    PreviewView(c).apply {
                        scaleType = PreviewView.ScaleType.FILL_CENTER
                        session.start(this, { bmp -> engine.submit(bmp) }, { m -> status = m })
                    }
                }, modifier = Modifier.fillMaxWidth().height(320.dp))

                val f = frame
                val text = when {
                    !engine.ready -> "Modelo no cargado."
                    f == null -> "Esperando imagen de la cámara…"
                    !f.handPresent -> "No se detecta ninguna mano: acércala, céntrala y mejora la luz."
                    f.gestures.isEmpty() -> "Mano detectada, pero el gesto no se reconoce con la confianza exigida. Prueba a bajar el umbral o a repetir el gesto."
                    else -> "Detectado: " + f.gestures.joinToString { it.label }
                }
                Text(text, style = MaterialTheme.typography.titleSmall)
                if (f != null && f.handPresent) Text("Modelo: ${f.rawLabel.ifBlank { "—" }} (${"%.2f".format(f.score)})", style = MaterialTheme.typography.bodySmall)

                Text("Umbral de confianza: ${"%.2f".format(minScore)} (más bajo = más sensible, pero más falsos positivos)")
                Slider(value = minScore, onValueChange = { minScore = it; store.minScore = it }, valueRange = 0.3f..0.95f)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(checked = runRules, onCheckedChange = { runRules = it })
                    Text("  Ejecutar mis reglas activas con los gestos")
                }
                Text("El reconocimiento funciona solo con esta pantalla abierta. Si una acción abre otra app, la cámara se detiene.", style = MaterialTheme.typography.bodySmall)
                if (status.isNotBlank()) Text(status)
            }
        }
    }
}
